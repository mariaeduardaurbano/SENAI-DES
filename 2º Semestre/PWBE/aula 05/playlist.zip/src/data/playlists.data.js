const playlists = [
    {
        "id":"123",
        "usuario_id":"456",
        "nome":"Hard Rock",
    },
    {
        "id":"789",
        "usuario_id":"765",
        "nome":"Rocks",
    },
];

module.exports = playlists; 