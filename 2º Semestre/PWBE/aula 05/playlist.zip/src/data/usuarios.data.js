const usuarios = [
    {
        "id":"123",
        "nome":"Maria Eduarda Urbano",
        "email":"m.eduardaurbano@gmail.com"
    },
    {
        "id":"789",
        "nome":"Mirella Brolezi",
        "email":"m.brolezi@gmail.com"
    },
];

module.exports = usuarios; 