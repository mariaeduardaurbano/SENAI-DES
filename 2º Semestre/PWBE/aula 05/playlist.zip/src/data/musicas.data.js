const musicas = [
    {
        "id":"123",
        "titulo":"How You Remind Me",
        "artista":"Nickelback",
        "duracao": "3:49"
    },
    {
        "id":"987",
        "titulo":"Far Away",
        "artista":"Nickelback",
        "duracao": "3:59"
    }
];

module.exports = musicas; 