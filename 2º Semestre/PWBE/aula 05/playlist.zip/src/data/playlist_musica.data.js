const playlist_musicas = [
    {
        "id": "123",
        "ordem":"Decrescente",
        "musica_id":"444",
        "playlist_id": "789"
    },
    {
        "id":"765",
        "ordem":"Decrescente",
        "musica_id":"333",
        "playlist_id": "123"
    }
];

module.exports = playlist_musicas; 