DROP DATABASE IF EXISTS musica;
CREATE DATABASE musica; 

/*----------------*/

USE musica;

/*----------------*/

CREATE TABLE usuarios (
    id INTEGER AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR (100) NOT NULL,
    email VARCHAR (30)
);

/*----------------*/

CREATE TABLE playlist (
    id INTEGER AUTO_INCREMENT PRIMARY KEY,
    usuario_id INTEGER,
    nome VARCHAR (50),
     FOREIGN KEY (usuario_id) REFERENCES playlist(id)
);

/*----------------*/

CREATE TABLE musicas (
    id INTEGER AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR (30),
    artista VARCHAR (40),
    duracao INTEGER,
);

/*----------------*/

CREATE TABLE playlist_musica (
id INTEGER AUTO_INCREMENT PRIMARY KEY,
musica_id INTEGER,
playlist_id INTEGER,
ordem INTEGER,
FOREIGN KEY (musica_id) REFERENCES musicas(id),
FOREIGN KEY (playlist_id) REFERENCES playlist(id)
);

/*----------------*/

INSERT INTO usuarios (id, nome, email)
VALUES (1, "Maria Eduarda Urbano", "m.eduardaurbano@gmail.com");

/*----------------*/

SELECT * FROM usuarios;

/*----------------*/

INSERT INTO playlist (id, usuario_id, nome)
VALUES (1, 1, "Beltrana Urbano de Oliveira");

/*----------------*/

SELECT * FROM playlist;

/*----------------*/

INSERT INTO musicas (id, titulo, artista, duracao)
VALUES (DEFAULT, "T.N.T", "AC/DC", 4);

/*----------------*/

SELECT * FROM musicas;

/*----------------*/

INSERT INTO playlist_musica (id,ordem, musica_id, playlist_id)
VALUES (DEFAULT, 7, "1", "1");

/*----------------*/

SELECT * FROM playlist_musica;

/*----------------*/

SELECT * FROM usuarios WHERE id = 1; 

/*----------------*/

SELECT * FROM playlist WHERE id = 1;

/*----------------*/

SELECT * FROM playlist_musica WHERE 1;

/*----------------*/

SELECT * FROM musicas WHERE 1;