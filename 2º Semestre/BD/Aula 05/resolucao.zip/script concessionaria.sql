DROP DATABASE IF EXISTS concessionaria;
CREATE DATABASE concessionaria;

/*----------------*/

USE  concessionaria;

/*----------------*/

CREATE TABLE clientes (
    id INTEGER AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR (100) NOT NULL,
    cpf INTEGER
);

/*----------------*/

CREATE TABLE veiculos (
    id INTEGER AUTO_INCREMENT PRIMARY KEY,
    modelo VARCHAR (40) NOT NULL,
    placa VARCHAR (20),
    categoria VARCHAR (30)
);

/*----------------*/

CREATE TABLE contratos (
    id INTEGER AUTO_INCREMENT PRIMARY KEY,
    cliente_id INTEGER,
    veiculo_id INTEGER,
    data_inicio DATETIME,
    data_fim DATETIME,
    valor FLOAT,
     FOREIGN KEY (cliente_id) REFERENCES clientes(id),
     FOREIGN KEY (veiculo_id) REFERENCES veiculos(id)
);

/*----------------*/

CREATE TABLE manutencoes(
id INTEGER AUTO_INCREMENT PRIMARY KEY,
veiculo_id INTEGER,
tipo VARCHAR (50),
data DATETIME,
observacao VARCHAR (30),
FOREIGN KEY (veiculo_id) REFERENCES veiculos(id)
);

/*----------------*/

INSERT INTO clientes (id, nome, cpf)
VALUES (1, "Maria Eduarda Urbano", "000.000.000-00");

/*----------------*/

SELECT * FROM clientes;

/*----------------*/

INSERT INTO veiculos (id, modelo, placa, categoria)
VALUES (1, "Chevrolet - ONIX", "DUB5192", "A");

/*----------------*/

SELECT * FROM veiculos;

/*----------------*/

INSERT INTO contratos (id, cliente_id, veiculo_id, data_inicio, data_fim, valor)
VALUES (1, 1, 1, "2025-05-07", "2026-07-05", "78.000,00");

/*----------------*/

SELECT * FROM contratos;

/*----------------*/

INSERT INTO manutencoes (id, veiculo_id, tipo, data, observacao)
VALUES (2, 1, "intermediária", "2025-08-24", "Verificar vazamento de óleo");

/*----------------*/

SELECT * FROM manutencoes;

/*----------------*/

SELECT * FROM clientes WHERE id = 1; 

/*----------------*/

SELECT * FROM veiculos WHERE id = 1;

/*----------------*/

SELECT * FROM contratos WHERE id = 1;

/*----------------*/

SELECT * FROM manutencoes WHERE id = 2;

