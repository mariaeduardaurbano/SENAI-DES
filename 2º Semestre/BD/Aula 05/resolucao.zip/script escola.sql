DROP DATABASE IF EXISTS escola;
CREATE DATABASE escola; 

/*----------------*/


USE  escola;

/*----------------*/

CREATE TABLE professores(
	id INTEGER AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR (100) NOT NULL,
    telefone VARCHAR (15),
    email VARCHAR (30)
);

/*----------------*/

CREATE TABLE disciplinas (
    id INTEGER AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR (50) NOT NULL,
    professor_id INTEGER
);

/*----------------*/

CREATE TABLE turmas (
    nome VARCHAR (50) NOT NULL,
    id INTEGER AUTO_INCREMENT PRIMARY KEY,
    periodo VARCHAR (30)
);

/*----------------*/

CREATE TABLE possui (
    turma_id INTEGER,
    disciplina_id INTEGER,
    FOREIGN KEY (turma_id) REFERENCES turmas(id),
    FOREIGN KEY (disciplina_id) REFERENCES disciplinas(id)
);

/*----------------*/

INSERT INTO professores (id, nome, telefone, email)
VALUES (1, "Maria Eduarda Urbano", "(19)99999-9999", "m.eduardaurbano@gmail.com");

/*----------------*/

SELECT * FROM professores;

/*----------------*/

INSERT INTO disciplinas (id, nome, professor_id)
VALUES (1, "Lingua Portuguesa", 1);

/*----------------*/

SELECT * FROM disciplinas;

/*----------------*/

INSERT INTO turmas (nome, id, periodo)
VALUES ("2º ano A", 1, "Integral");

/*----------------*/

SELECT * FROM turmas;

/*----------------*/

SELECT * FROM disciplinas WHERE id = 1; 

/*----------------*/

SELECT * FROM professores WHERE id = 1;

/*----------------*/

SELECT * FROM turmas WHERE id = 1;


